"""MAIN BASE FOUNDATION team service."""

from backend.database.service import DatabaseService
from backend.teams.model import Team


class TeamService:
    """Persist and manage organization teams."""

    def __init__(self):
        self.database = DatabaseService()

    def initialize(self):
        self.database.initialize()
        self.database.execute("""
        CREATE TABLE IF NOT EXISTS teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            team_id TEXT UNIQUE,
            team_name TEXT,
            display_name TEXT,
            organization_id TEXT,
            team_leader_id TEXT,
            description TEXT,
            status TEXT
        )
        """)
        return {"teams": "Initialized", "status": "READY"}

    def create_team(self, team_id, team_name, display_name, organization_id,
                    team_leader_id, description, status="ACTIVE"):
        return Team(
            team_id=team_id,
            team_name=team_name,
            display_name=display_name,
            organization_id=organization_id,
            team_leader_id=team_leader_id,
            description=description,
            status=status,
        )

    def save_team(self, team):
        self.database.execute(
            """
            INSERT OR REPLACE INTO teams
            (team_id, team_name, display_name, organization_id,
             team_leader_id, description, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (team.team_id, team.team_name, team.display_name,
             team.organization_id, team.team_leader_id,
             team.description, team.status),
        )

    def get_team(self, team_id):
        row = self.database.fetchone(
            """SELECT team_id, team_name, display_name, organization_id,
                      team_leader_id, description, status
               FROM teams WHERE team_id = ?""",
            (team_id,),
        )
        if row is None:
            return None
        return Team(*row)

    def update_team(self, team_id, team_name, display_name, organization_id,
                    team_leader_id, description, status):
        self.database.execute(
            """UPDATE teams SET team_name=?, display_name=?, organization_id=?,
                      team_leader_id=?, description=?, status=?
               WHERE team_id=?""",
            (team_name, display_name, organization_id, team_leader_id,
             description, status, team_id),
        )

    def delete_team(self, team_id):
        self.database.execute("DELETE FROM teams WHERE team_id = ?", (team_id,))

    def get_all_teams(self):
        return self.database.fetchall(
            """SELECT team_id, team_name, display_name, organization_id,
                      team_leader_id, description, status FROM teams"""
        )

    def search_team_by_name(self, team_name):
        return self.database.fetchone(
            """SELECT team_id, team_name, display_name, organization_id,
                      team_leader_id, description, status
               FROM teams WHERE team_name = ?""",
            (team_name,),
        )
