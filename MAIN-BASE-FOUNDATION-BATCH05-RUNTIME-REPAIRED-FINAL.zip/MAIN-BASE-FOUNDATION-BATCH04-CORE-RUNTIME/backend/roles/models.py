"""Role models for MAIN BASE FOUNDATION."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class Role:
    """A named authorization role with assigned permission identifiers."""
    role_id: str
    name: str
    permissions: List[str] = field(default_factory=list)
    status: str = "active"


__all__ = ["Role"]
