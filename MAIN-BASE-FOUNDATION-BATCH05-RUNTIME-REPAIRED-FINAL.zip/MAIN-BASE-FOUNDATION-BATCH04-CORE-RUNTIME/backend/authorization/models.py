"""Authorization data models for MAIN BASE FOUNDATION."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AuthorizationRequest:
    request_id: str
    subject_id: str
    resource: str
    action: str
    scope: str
    provider_id: Optional[str] = None
    server_id: Optional[str] = None
    connection_id: Optional[str] = None
    reason: Optional[str] = None
    status: str = "PENDING"
    metadata: dict = field(default_factory=dict)


__all__ = ["AuthorizationRequest"]
