"""Team service for MAIN BASE FOUNDATION.

This service provides an import-safe CRUD facade. Persistence can be
connected to the repository database layer without changing the public API.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Dict, List, Optional


@dataclass
class Team:
    team_id: str
    name: str
    organization_id: Optional[str] = None
    status: str = "active"
    created_at: str = ""


class TeamService:
    """In-memory team service with a stable application-facing contract."""

    def __init__(self) -> None:
        self._teams: Dict[str, Team] = {}

    def initialize(self) -> dict:
        return {"status": "initialized", "service": "teams"}

    def create_team(
        self,
        team_id: str,
        name: str,
        organization_id: Optional[str] = None,
    ) -> dict:
        if not team_id or not name:
            raise ValueError("team_id and name are required")
        if team_id in self._teams:
            raise ValueError(f"team already exists: {team_id}")
        team = Team(
            team_id=team_id,
            name=name,
            organization_id=organization_id,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._teams[team_id] = team
        return asdict(team)

    def save_team(self, team: Team) -> dict:
        if not isinstance(team, Team):
            raise TypeError("team must be a Team instance")
        self._teams[team.team_id] = team
        return asdict(team)

    def get_team(self, team_id: str) -> Optional[dict]:
        team = self._teams.get(team_id)
        return asdict(team) if team else None

    def list_teams(self) -> List[dict]:
        return [asdict(team) for team in self._teams.values()]

    def update_team(self, team_id: str, **changes: object) -> dict:
        team = self._teams.get(team_id)
        if team is None:
            raise KeyError(team_id)
        for key, value in changes.items():
            if key not in {"name", "organization_id", "status"}:
                raise ValueError(f"unsupported team field: {key}")
            setattr(team, key, value)
        return asdict(team)

    def delete_team(self, team_id: str) -> bool:
        return self._teams.pop(team_id, None) is not None


# Stable default service instance for lightweight integrations.
service = TeamService()
