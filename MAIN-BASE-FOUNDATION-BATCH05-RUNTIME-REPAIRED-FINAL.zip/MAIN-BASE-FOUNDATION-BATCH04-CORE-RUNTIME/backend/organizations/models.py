"""Compatibility exports for organization models."""
from .model import Organization

__all__ = ["Organization"]
