Security Module
