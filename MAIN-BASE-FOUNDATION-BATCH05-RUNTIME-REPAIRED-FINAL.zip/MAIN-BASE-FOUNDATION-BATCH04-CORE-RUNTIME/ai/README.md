AI Module
